﻿using var game = new Lesson12_MosquitoAttack_Inheritance.MosquitoAttack();
game.Run();
